
document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady() {
  window.deviceready = true;
}
