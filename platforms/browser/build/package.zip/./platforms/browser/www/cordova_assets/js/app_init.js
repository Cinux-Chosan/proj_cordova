
document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady() {
  alert('deviceready');
  window.deviceready = true;
}
