function onDeviceReady(){alert("deviceready"),window.deviceready=!0}document.addEventListener("deviceready",onDeviceReady,!1)
